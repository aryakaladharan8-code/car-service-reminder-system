<?php
session_start();
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="refresh" content="3;url=login.php">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Logging Out...</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      height: 100vh;
      background: linear-gradient(135deg, #dbeafe, #e0f2fe, #f0f9ff); /* light blue pastel gradient */
      display: flex;
      justify-content: center;
      align-items: center;
      animation: fadeIn 1s ease-in;
    }

    .message-box {
      background: rgba(255, 255, 255, 0.85);
      padding: 40px 60px;
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
      border-radius: 16px;
      text-align: center;
      max-width: 400px;
      width: 90%;
      transition: all 0.3s ease;
    }

    h2 {
      color: #000;
      margin-bottom: 12px;
      font-size: 26px;
    }

    p {
      color: #000;
      font-size: 16px;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
  <div class="message-box">
    <h2>You have been logged out.</h2>
    <p>Redirecting to login page...</p>
  </div>
</body>
</html>

