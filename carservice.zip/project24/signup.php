<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register - Car Service Management</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body, html {
      height: 100%;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: url('https://www.mechanicbuddy.co.za/media/BusinessImage/teecheez-auto-repairs/dc02de3f-4ace-4f50-bae1-bffa34078327.jpg') no-repeat center center fixed;
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .container {
      display: flex;
      justify-content: space-between;
      width: 100%;
      max-width: 1200px;
      padding: 40px;
    }

    .info-panel {
      width: 55%;
      color: #ffffff;
      text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
      padding-right: 40px;
      animation: slideLeft 0.8s ease;
    }

    .title-group {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 20px;
    }

    .title-group h1 {
      font-size: 3em;
      margin: 0;
      color: #ffffff;
      text-shadow: 1px 1px 4px rgba(0, 0, 0, 0.6);
    }

    .title-group img.logo {
      width: 70px;
      height: auto;
      filter: drop-shadow(0 0 5px rgba(0,0,0,0.3));
    }

    .info-panel p {
      font-size: 1.2em;
      margin-bottom: 15px;
      line-height: 1.6;
    }

    .register-box {
      width: 30%;
      background: rgba(255, 255, 255, 0.2);
      backdrop-filter: blur(15px);
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
      color: #fff;
      text-align: center;
      animation: slideRight 0.8s ease;
    }

    .register-box h2 {
      margin-bottom: 25px;
      font-size: 2em;
      color: #ffffff;
      text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
    }

    input {
      width: 100%;
      padding: 12px;
      margin: 12px 0;
      border: none;
      border-radius: 8px;
      font-size: 1em;
      background-color: rgba(255, 255, 255, 0.9);
      color: #333;
    }

    input::placeholder {
      color: #555;
    }

    button {
      width: 100%;
      padding: 12px;
      margin-top: 15px;
      border: none;
      border-radius: 8px;
      font-size: 1em;
      font-weight: bold;
      background: #28a745;
      color: white;
      cursor: pointer;
      transition: background 0.3s ease, transform 0.2s ease;
    }

    button:hover {
      background: #218838;
      transform: translateY(-2px);
    }

    .link {
      margin-top: 15px;
      color: #f1f1f1;
    }

    .link a {
      color: #ffeb3b;
      text-decoration: none;
      font-weight: bold;
    }

    .link a:hover {
      text-decoration: underline;
    }

    @keyframes slideRight {
      from { opacity: 0; transform: translateX(80px); }
      to { opacity: 1; transform: translateX(0); }
    }

    @keyframes slideLeft {
      from { opacity: 0; transform: translateX(-80px); }
      to { opacity: 1; transform: translateX(0); }
    }

    @media (max-width: 900px) {
      .container {
        flex-direction: column;
        align-items: center;
        padding: 20px;
      }

      .info-panel, .register-box {
        width: 100%;
        text-align: center;
      }

      .info-panel {
  text-align: left;       /* Align text to left */
  padding-left: 0px;     /* Add padding if you want spacing from edge */
}


      .info-panel h1 {
        font-size: 2.2em;
      }

      .title-group {
  display: flex;
  align-items: center;
  gap: 0px;
  justify-content: flex-start; /* Ensures left alignment */
  margin-left: 0;              /* Remove any centering */
}

      .title-group img.logo {
        margin-top: 10px;
      }
    }
  </style>
</head>
<body>
 <div class="info-panel">
  <div class="title-group" >
    
    <img class="logo" src="maintenance.png" alt="Car Logo" style="width: 70px; height: auto;" />
  <h1 style="margin: 0;">Car Care Service </h1>
  </div>
  <p>🔧 Stay ahead with timely service updates</p>
  <p>🚗 Keep your vehicle running at its best</p>
  <p>📅 Never miss a service date again!</p>
</div>


    <div class="register-box">
      <h2>Create an Account</h2>
      <form action="signupprocess.php" method="POST">
        <input type="text" name="name" placeholder="Full Name" required />
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <input type="password" name="confirm_password" placeholder="Confirm Password" required />

        <button type="submit">📝 Sign Up</button>

        <div class="link">
          Already have an account? <a href="login.php">Login</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>

