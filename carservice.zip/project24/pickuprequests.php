<?php
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get pickup requests where pickuprequired = 'Yes' and include customer name
$sql = "SELECT b.*, u.name AS customername 
        FROM bookings b 
        LEFT JOIN user u ON b.userid = u.userid 
        WHERE TRIM(LOWER(b.pickuprequired)) = '1'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Pickup Requests</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #c9d8f8ff;
      margin: 0;
      padding: 30px 20px;
    }

    .container {
      max-width: 1200px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #1e3a8a;
      font-size: 26px;
      margin-bottom: 30px;
    }

    h2::before {
      content: "🚚 ";
    }

    table {
      width: 100%;
      border-collapse: collapse;
      overflow: hidden;
    }

    th {
      background-color: #1e3a8a;
      color: white;
      padding: 14px;
      text-align: left;
      font-size: 16px;
    }

    td {
      padding: 13px 15px;
      font-size: 15px;
      color: #333;
      border-bottom: 1px solid #ddd;
    }

    tr:nth-child(even) {
      background-color: #edf0fa;
    }

    tr:hover {
      background-color: #e0e7ff;
    }

    .no-data {
      color: #9e9e9e;
      font-size: 18px;
      text-align: center;
      margin: 40px 0;
    }

    .back-btn, .export-btn {
      display: inline-block;
      margin-top: 30px;
      padding: 10px 25px;
      background-color: #1e3a8a;
      color: white;
      border: none;
      font-weight: 600;
      text-decoration: none;
      font-size: 16px;
      border-radius: 8px;
      box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      text-align: center;
      cursor: pointer;
    }

    .back-btn:hover, .export-btn:hover {
      background-color: #000;
      color: #fff;
    }

    .button-wrapper {
      text-align: center;
      display: flex;
      justify-content: center;
      gap: 15px;
      flex-wrap: wrap;
    }

    /* ✅ PRINT SETTINGS - Makes PDF larger and readable */
    @media print {
      body {
        background-color: white;
        color: black;
        margin: 0;
        padding: 0;
        zoom: 1.3; /* increase text size */
      }

      .container {
        width: 100%;
        margin: 0;
        padding: 20px;
        box-shadow: none;
      }

      table {
        font-size: 16px;
        width: 100%;
      }

      th, td {
        padding: 10px;
      }

      .export-btn, .back-btn {
        display: none; /* hide buttons in PDF */
      }

      @page {
        size: A3 portrait; /* larger page */
        margin: 0.5in;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Pickup Requests</h2>

    <?php
    if ($result && $result->num_rows > 0) {
      echo "<table>";
      echo "<tr>
              <th>Booking ID</th>
              <th>Customer Name</th>
              <th>Car Number</th>
              <th>Pickup Address</th>
              <th>Area</th>
              <th>Pickup Price</th>
              <th>Service Date</th>
            </tr>";
      while ($row = $result->fetch_assoc()) {
        $bookingId = htmlspecialchars($row['bookingid']);
        $customerName = htmlspecialchars($row['customername'] ?? $row['userid']);
        $carNumber = htmlspecialchars($row['carnumber'] ?? '');
        $pickupAddress = htmlspecialchars($row['pickupaddress'] ?? '');
        $area = htmlspecialchars($row['areaname'] ?? '');
        $pickupPrice = htmlspecialchars($row['pickupprice'] ?? '0');
        $serviceDate = htmlspecialchars($row['servicedate'] ?? '');

        echo "<tr>
                <td>{$bookingId}</td>
                <td>{$customerName}</td>
                <td>{$carNumber}</td>
                <td>{$pickupAddress}</td>
                <td>{$area}</td>
                <td>₹{$pickupPrice}</td>
                <td>{$serviceDate}</td>
              </tr>";
      }
      echo "</table>";
    } else {
      echo "<p class='no-data'>No pickup requests found.</p>";
    }
    $conn->close();
    ?>
    
    <div class="button-wrapper">
    
    <a class="back-btn" href="admindashboard.php">← Back to Dashboard</a>

      <button class="export-btn" onclick="window.print()">📄 Export as PDF</button>

    </div>

  </div>
  

</body>
</html>
