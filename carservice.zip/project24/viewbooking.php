<?php
$conn = new mysqli("localhost", "root", "", "carservice");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Handle booking deletion
if (isset($_GET['delete'])) {
    $deleteid = $_GET['delete'];
    $conn->query("DELETE FROM bookings WHERE bookingid = $deleteid");
    header("Location: viewbooking.php"); // Refresh page after deletion
    exit();
}

// Fetch bookings with user name
$sql = "SELECT b.*, u.name 
        FROM bookings b 
        JOIN user u ON b.userid = u.userid 
        ORDER BY b.bookingid DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Service Bookings - Admin</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, sans-serif;
      background-color: #f5f7fb;
      margin: 0;
      padding: 20px;
      color: #333;
    }

    .container {
      max-width: 1400px;
      margin: auto;
      background-color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
      padding: 35px;
      overflow-x: auto;
    }

    h2 {
      text-align: center;
      color: #1e3a8a;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 15px;
    }

    thead {
      background-color: #1e3a8a;
      color: white;
    }

    th, td {
      padding: 14px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }

    tbody tr:nth-child(even) {
      background-color: #f7f9ff;
    }

    tbody tr:hover {
      background-color: #e9f0ff;
    }

    .back {
      display: block;
      text-align: center;
      margin-top: 25px;
      text-decoration: none;
      color: white;
      font-weight: 500;
      background-color: #1e3a8a;
      padding: 10px 20px;
      border-radius: 8px;
      width: fit-content;
      margin-left: auto;
      margin-right: auto;
      transition: background-color 0.3s ease;
    }

    .back:hover {
      background-color: #000;
      color: white;
    }

    .pickup-yes {
      color: green;
      font-weight: bold;
    }

    .pickup-no {
      color: gray;
      font-style: italic;
    }

    .delete-btn {
      color: red;
      font-weight: bold;
      text-decoration: none;
      transition: color 0.2s;
    }

    .delete-btn:hover {
      color: darkred;
    }

    select {
      padding: 6px;
      border-radius: 6px;
    }

    /* ✅ PRINT SETTINGS (Fixes half-page cut issue) */
   /* ✅ FINAL FIX: No cutoff, full-page printing */
@media print {
  html, body {
    background: #fff !important;
    color: #000 !important;
    margin: 0;
    padding: 0;
    height: auto !important;
    overflow: visible !important; /* ✅ Ensures full content prints */
  }

  .container {
    box-shadow: none;
    border-radius: 0;
    padding: 10px;
    margin: 0;
    width: 100%;
    max-width: none;
  }

  .back, button {
    display: none !important; /* Hide buttons when printing */
  }

  table {
    width: 100%;
    border-collapse: collapse;
    page-break-inside: auto;
    font-size: 12px;
    table-layout: fixed;
    word-wrap: break-word;
  }

  th, td {
    padding: 6px;
    border: 1px solid #999;
    text-align: center;
  }

  thead {
    display: table-header-group; /* ✅ Repeats header on each page */
  }

  tr {
    page-break-inside: avoid;
    page-break-after: auto;
  }

  @page {
    size: A4 portrait; /* Use landscape if table is wide */
    margin: 10mm;
  }

  /* ✅ Auto shrink to fit entire page width */
  body {
    zoom: 0.9; /* Adjust between 0.8–1.0 based on how much is cut off */
    transform: scale(0.9);
    transform-origin: top center;
  }
}

  </style>
</head>
<body>
  <div class="container">
    <h2>📋 All Service Bookings</h2>

    <div style="text-align:center; margin-bottom:20px;">
      <button onclick="window.print()" 
              style="background-color:#1e3a8a; color:white; border:none; 
                     padding:10px 20px; border-radius:8px; font-size:15px; 
                     cursor:pointer; transition:background-color 0.3s;">
        📄 Export as PDF
      </button>
    </div>

    <table>
      <thead>
        <tr>
          <th>User Name</th>
          <th>Car Number</th>
          <th>Car Model</th>
          <th>Service Type</th>
          <th>Service Price</th>
          <th>Pickup?</th>
          <th>Area</th>
          <th>Pickup Price</th>
          <th>Pickup Address</th>
          <th>Total Price</th>
          <th>Service Date</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $pickup = $row['pickuprequired'] ? '<span class="pickup-yes">Yes</span>' : '<span class="pickup-no">No</span>';
                $pickuparea = $row['pickuprequired'] ? $row['areaname'] : '-';
                $pickupprice = $row['pickuprequired'] ? '₹' . $row['pickupprice'] : '-';
                $pickupaddress = $row['pickuprequired'] ? $row['pickupaddress'] : '-';
                $totalprice = '₹' . $row['totalprice'];
                ?>
                <tr>
                  <td><?= $row['name'] ?></td>
                  <td><?= $row['carnumber'] ?></td>
                  <td><?= $row['carmodel'] ?></td>
                  <td><?= $row['servicetype'] ?></td>
                  <td>₹<?= $row['price'] ?></td>
                  <td><?= $pickup ?></td>
                  <td><?= $pickuparea ?></td>
                  <td><?= $pickupprice ?></td>
                  <td><?= $pickupaddress ?></td>
                  <td><?= $totalprice ?></td>
                  <td><?= $row['servicedate'] ?></td>
                  <td>
                    <?php if (strtolower($row['status']) === 'pending'): ?>
                      <form action='updatestatus.php' method='post' style='margin:0;'>
                        <input type='hidden' name='bookingid' value='<?= $row['bookingid'] ?>'>
                        <select name='status' onchange='this.form.submit()'>
                          <option value='Pending' selected>Pending</option>
                          <option value='Completed'>Completed</option>
                        </select>
                      </form>
                    <?php else: ?>
                      <span style="color: darkblue; font-weight: bold;">Completed</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <a href="viewbooking.php?delete=<?= $row['bookingid'] ?>" 
                       onclick="return confirm('Are you sure you want to delete this booking?');" 
                       class="delete-btn">Delete</a>
                  </td>
                </tr>
                <?php
            }
        } else {
            echo "<tr><td colspan='13'>No bookings found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

  <a class="back" href="admindashboard.php">← Back to Dashboard</a>
</body>
</html>
