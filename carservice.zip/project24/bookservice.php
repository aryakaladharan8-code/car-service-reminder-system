<?php
session_start();
$conn = new mysqli("localhost", "root", "", "carservice");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userid = $_SESSION['userid'] ?? null;

if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo "<script>
        alert('✅ Thank you! Your service is booked.');
        setTimeout(function() {
            window.location.href = 'userdashboard.php';
        }, 2500);
    </script>";
}

// Check if any pickup slots are available for tomorrow
$tomorrow = date('Y-m-d', strtotime('+1 day'));

$pickupCheck = $conn->query("SELECT COUNT(*) as cnt FROM availableslots WHERE slotdate='$tomorrow' AND pickupoption='pickup'");
$pickupRow = $pickupCheck->fetch_assoc();
$pickupAvailable = $pickupRow['cnt'] > 0;

$pickupSlotCheck = $conn->query("SELECT COUNT(*) as cnt FROM availableslots WHERE slotdate='$tomorrow' AND pickupoption='pickup' AND currentbookings < maxbookings");
$pickupSlotsAvailable = $pickupSlotCheck->fetch_assoc()['cnt'] > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Service Booking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to right, #ccdaf7ff);
      display: flex; justify-content: center; align-items: center;
      padding: 30px 15px; min-height: 100vh; color: #333;
    }
    .form-container {
      background: linear-gradient(135deg, #ffffff, #f3f6fc);
      padding: 30px 25px;
      border-radius: 16px;
      border: 1px solid #08080aff;
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
      width: 100%; max-width: 540px;
    }
    h2 { text-align: center; margin-bottom: 25px; color: #1e3a8a; font-size: 22px; font-weight: 600; }
    .form-group { margin-bottom: 16px; padding: 12px 14px; background-color: #f9fbff; border: 1px solid #d1dce8; border-radius: 10px; }
    .form-group label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 14.5px; color: #1a1a1a; }
    .form-group input, .form-group select, .form-group textarea {
      width: 100%; padding: 10px 12px; border-radius: 8px; background-color: #f9faff;
      border: 1px solid #060b1bff; color: #0e0909ff; font-size: 14px; transition: all 0.3s ease;
    }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
      outline: none; border-color: #1e3a8a; background-color: #fff;
      box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.1);
    }
    #visiblepickupprice { background-color: #333; color: #fff; font-weight: bold; border: none; }
    .submit-btn {
      width: 100%; padding: 12px; background-color: #1e3a8a; color: #fff; font-weight: 600; border: none;
      border-radius: 8px; cursor: pointer; font-size: 15px; transition: background 0.3s, transform 0.2s;
      box-shadow: 0 4px 10px rgba(30, 58, 138, 0.2);
    }
    .submit-btn:hover { background-color: #15317e; transform: scale(1.02); }
    #pickupfields { display: none; }
  </style>
</head>
<body>
<div class="form-container">
<h2>🔧🚗 Service Booking</h2>
<form action="processbooking.php" method="POST">
<input type="hidden" name="pickupprice" id="pickupprice" value="0">

<!-- Standard fields -->
<div class="form-group">
  <label for="carnumber">Car Number:</label>
  <input type="text" name="carnumber" id="carnumber" required>
</div>

<div class="form-group">
  <label for="carmodel">Car Model:</label>
  <input type="text" name="carmodel" id="carmodel" required>
</div>

<div class="form-group">
  <label for="phonenumber">Phone Number:</label>
  <input type="text" name="phonenumber" id="phonenumber" required pattern="[0-9]{10}" placeholder="Enter 10-digit number">
</div>

<div class="form-group">
  <label for="servicetype">Service Type:</label>
  <select name="servicetype" id="servicetype" required>
    <option value="">-- Select Service --</option>
    <option value="Oil Change">Oil Change - ₹800 (⏰ Reminder in 3 months)</option>
    <option value="Full Service">Full Service - ₹1500 (⏰ Reminder in 6 months)</option>
    <option value="Brake Inspection">Brake Inspection - ₹600 (⏰ Reminder in 6 months)</option>
    <option value="Battery Check">Battery Check - ₹400 (⏰ Reminder in 6 months)</option>
    <option value="Coolant Flush">Coolant Flush - ₹1000 (⏰ Reminder in 2 years)</option>
    <option value="Tire Rotation">Tire Rotation - ₹600 (⏰ Reminder in 6 months)</option>
    <option value="Air Filter Replacement">Air Filter Replacement - ₹500 (⏰ Reminder in 1 year)</option>
    <option value="Suspension Check">Suspension Check - ₹1000 (⏰ Reminder in 1 year)</option>
    <option value="AC Repair">AC Repair - ₹1000</option>
  </select>
</div>

<div class="form-group">
  <label for="price">Service Price (₹):</label>
  <input type="number" name="price" id="price" readonly required>
</div>

<div class="form-group">
  <label>Service Date:</label>
  <input type="text" readonly value="<?php echo date('l, d M Y', strtotime('+1 day')); ?>">
</div>

<!-- Pickup option -->
<div class="form-group">
  <label for="pickuprequired">Need Pickup?</label>
  <select name="pickuprequired_temp" id="pickuprequired_temp" required>
    <option value="">-- Select --</option>
    <option value="1">Yes</option>
    <option value="0">No</option>
  </select>
  <input type="hidden" name="pickuprequired" id="pickuprequired" value="0">
</div>

<div id="pickupmessage" style="display:none; color:#d9534f; font-weight:bold; margin-top:8px;">
</div>

<!-- Pickup-related fields -->
<div id="pickupfields">
  <div class="form-group">
    <label for="slotid">Select Pickup Time Slot:</label>
    <select name="slotid" id="slotid">
      <option value="">-- Select Available Slot --</option>
      <?php
      $sql = "SELECT slotid, slotdate, slottime FROM availableslots 
              WHERE slotdate = '$tomorrow' 
              AND currentbookings < maxbookings 
              AND pickupoption = 'pickup'
              ORDER BY slottime";
      $result = $conn->query($sql);
      while ($row = $result->fetch_assoc()) {
          $slotLabel = $row['slotdate'] . " — " . $row['slottime'];
          echo "<option value='" . $row['slotid'] . "'>$slotLabel</option>";
      }
      ?>
    </select>
  </div>

  <div class="form-group">
    <label for="areaname">Select Area:</label>
    <select name="areaname" id="areaname">
      <option value="">-- Select Area --</option>
      <?php
      $sql = "SELECT areaname FROM pickuprequests ORDER BY areaname";
      $result = $conn->query($sql);
      while ($row = $result->fetch_assoc()) {
          echo "<option value='" . $row['areaname'] . "'>" . $row['areaname'] . "</option>";
      }
      ?>
    </select>
  </div>

  <div class="form-group">
    <label>Pickup Price (₹):</label>
    <input type="text" id="visiblepickupprice" readonly>
  </div>

  <div class="form-group">
    <label for="pickupaddress">Pickup Address:</label>
    <textarea name="pickupaddress" id="pickupaddress" rows="3" placeholder="e.g., House name, street, landmark..."></textarea>
  </div>
</div>

<!-- Total -->
<div class="form-group">
  <label for="totalprice">Total Price (₹):</label>
  <input type="number" id="totalprice" name="totalprice" readonly>
</div>

<button type="submit" class="submit-btn">Book Now</button>
</form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const pickupDropdown = document.getElementById("pickuprequired_temp");
  const pickupHidden = document.getElementById("pickuprequired");
  const pickupFields = document.getElementById("pickupfields");
  const pickupMessage = document.getElementById("pickupmessage");

  const pickupAvailable = <?php echo $pickupAvailable ? 'true' : 'false'; ?>;
  const pickupSlotsAvailable = <?php echo $pickupSlotsAvailable ? 'true' : 'false'; ?>;

  function updatePickup() {
    const val = pickupDropdown.value;
    pickupHidden.value = val;
    const isPickup = val === "1";

    if (isPickup && !pickupSlotsAvailable) {
      pickupFields.style.display = "none";
      pickupMessage.innerText = "🚫 All pickup slots are full for tomorrow. Please try again later.";
      pickupMessage.style.display = "block";
    } else if (isPickup) {
      pickupFields.style.display = "block";
      pickupMessage.style.display = "none";
    } else {
      pickupFields.style.display = "none";
      pickupMessage.style.display = pickupAvailable ? "none" : "block";
      pickupMessage.innerText = "🚫 Pickup is not available at this moment.";
    }
  }

  if (!pickupAvailable) {
    pickupDropdown.value = "0";
    updatePickup();
    pickupDropdown.style.opacity = "0.5";
    pickupDropdown.style.pointerEvents = "none";
  }

  pickupDropdown.addEventListener("change", updatePickup);

  const servicePrices = {
    "Oil Change": 800,
    "Full Service": 1500,
    "Brake Inspection": 600,
    "AC Repair": 1000,
    "Battery Check": 400,
    "Coolant Flush": 1000,
    "Tire Rotation": 600,
    "Air Filter Replacement": 500,
    "Suspension Check": 1000
  };

  const pickupPrices = {
    <?php
    $sql = "SELECT areaname, pickupprice FROM pickuprequests";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        echo "'" . addslashes($row['areaname']) . "': " . $row['pickupprice'] . ", ";
    }
    ?>
  };

  const servicetype = document.getElementById("servicetype");
  const price = document.getElementById("price");
  const pickupRequired = document.getElementById("pickuprequired");
  const areaname = document.getElementById("areaname");
  const totalPrice = document.getElementById("totalprice");
  const pickupAddress = document.getElementById("pickupaddress");
  const form = document.querySelector("form");

  servicetype.addEventListener("change", function () {
    const selected = servicetype.value;
    price.value = servicePrices[selected] || 0;
    updateTotal();
  });

  pickupRequired.addEventListener("change", updateTotal);
  areaname.addEventListener("change", updateTotal);

  function updateTotal() {
    const serviceAmount = parseFloat(price.value) || 0;
    let pickupAmount = 0;
    if (pickupRequired.value === "1") {
      const area = areaname.value;
      if (area && pickupPrices[area]) {
        pickupAmount = parseFloat(pickupPrices[area]) || 0;
      }
    }
    document.getElementById("pickupprice").value = pickupAmount.toFixed(2);
    document.getElementById("visiblepickupprice").value = pickupAmount > 0 ? "₹" + pickupAmount.toFixed(2) : "₹0.00";
    totalPrice.value = (serviceAmount + pickupAmount).toFixed(2);
  }

  form.addEventListener("submit", function (e) {
    if (pickupRequired.value === "1") {
      const address = pickupAddress.value.trim().toLowerCase();
      const area = areaname.value.trim().toLowerCase();

      if (!pickupAddress.value.trim()) {
        e.preventDefault();
        alert("🚚 Please enter a valid pickup address.");
        return;
      }

      if (!area || address.indexOf(area) === -1) {
        e.preventDefault();
        alert("⚠️ Pickup address must include the selected area name.");
        return;
      }
    }
  });

  updateTotal();
});
</script>

</body>
</html>
