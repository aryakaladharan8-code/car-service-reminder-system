
<?php
// ✅ Start output buffering to avoid accidental output
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ✅ Connect to DB
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Get form data
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

// ✅ Prepare & execute SQL
$stmt = $conn->prepare("SELECT userid, email, password, role FROM user WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        // ✅ Set session values
        $_SESSION['userid'] = $user['userid'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];

        // ✅ Redirect
        if ($user['role'] === 'Admin') {
            header("Location: admindashboard.php");
        } else {
            header("Location: userdashboard.php");
        }
        exit(); // ✅ stop script here
    } else {
        // ❌ Invalid password
        echo "<script>alert('Incorrect password'); window.location.href='login.php';</script>";
    }
} else {
    // ❌ User not found
    echo "<script>alert('User not found'); window.location.href='login.php';</script>";
}

// ✅ Clean up
$stmt->close();
$conn->close();
ob_end_flush(); // ✅ End output buffering
?>
