<?php
session_start();
$conn = new mysqli("localhost", "root", "", "carservice");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['userid'])) {
    die("You must be logged in to book a service.");
}

$userid = $_SESSION['userid'];

// Booking details
$carnumber = $_POST['carnumber'];
$carmodel = $_POST['carmodel'];
$phonenumber = $_POST['phonenumber'];
$servicetype = $_POST['servicetype'];
$price = $_POST['price'];
$pickuprequired = $_POST['pickuprequired'];
$areaname = $_POST['areaname'] ?? null;
$pickupaddress = $_POST['pickupaddress'] ?? null;
$pickupprice = $_POST['pickupprice'] ?? 0;
$totalprice = $_POST['totalprice'];

$approvalstatus = "Pending";
$status = "Pending";
$slotid = null;
$servicetime = null;
$servicedate = date('Y-m-d', strtotime('+1 day'));

// If pickup selected, get slot details
if ($pickuprequired == "1") {
    $slotid = isset($_POST['slotid']) ? (int)$_POST['slotid'] : 0;

    if ($slotid <= 0) die("Invalid slot selected.");

    $slotstmt = $conn->prepare("SELECT slotdate, slottime FROM availableslots WHERE slotid = ?");
    $slotstmt->bind_param("i", $slotid);
    $slotstmt->execute();
    $slotresult = $slotstmt->get_result();

    if ($slotresult->num_rows == 0) die("Invalid slot selected.");

    $slot = $slotresult->fetch_assoc();
    $servicedate = $slot['slotdate'];
    $servicetime = $slot['slottime'];
}

$expecteddelivery = date('Y-m-d', strtotime($servicedate . ' +2 days'));

// ✅ Final corrected binding
$stmt = $conn->prepare("INSERT INTO bookings 
(userid, carnumber, carmodel, phonenumber, servicetype, price, servicedate, servicetime, expecteddelivery, pickuprequired, areaname, pickupaddress, pickupprice, totalprice, approvalstatus, status, slotid) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// ✅ Corrected bind_param string
$stmt->bind_param("issssdsssissdsssi",
    $userid, $carnumber, $carmodel, $phonenumber, $servicetype, $price,
    $servicedate, $servicetime, $expecteddelivery,
    $pickuprequired, $areaname, $pickupaddress, $pickupprice, $totalprice,
    $approvalstatus, $status, $slotid
);

if ($stmt->execute()) {
    if ($pickuprequired == "1" && $slotid) {
        $updateslot = $conn->prepare("UPDATE availableslots SET currentbookings = currentbookings + 1 WHERE slotid = ?");
        $updateslot->bind_param("i", $slotid);
        $updateslot->execute();
    }

    // Auto Reminder Setup
    $reminderIntervals = [
        "Oil Change" => "+3 months",
        "Brake Inspection" => "+6 months",
        "Battery Replacement" => "+2 years",
        "Coolant Flush" => "+2 years",
        "Tire Rotation" => "+6 months",
        "Air Filter Replacement" => "+12 months",
        "Suspension Check" => "+12 months",
        "Full Service" => "+6 months"
    ];

    if (array_key_exists($servicetype, $reminderIntervals)) {
        $nextReminderDate = date('Y-m-d', strtotime($servicedate . ' ' . $reminderIntervals[$servicetype]));
        $reminderMessage = "Reminder: Your $servicetype for car $carnumber was done on $servicedate. Please book it again before $nextReminderDate.";

        $check = $conn->prepare("SELECT id FROM reminders WHERE userid = ? AND carnumber = ? AND type = ? AND reminderdate = ?");
        $check->bind_param("isss", $userid, $carnumber, $servicetype, $nextReminderDate);
        $check->execute();
        $check->store_result();

        if ($check->num_rows == 0) {
            $reminderStmt = $conn->prepare("INSERT INTO reminders (userid, carnumber, type, reminderdate, message, notified) VALUES (?, ?, ?, ?, ?, 0)");
            $reminderStmt->bind_param("issss", $userid, $carnumber, $servicetype, $nextReminderDate, $reminderMessage);
            $reminderStmt->execute();
            $reminderStmt->close();
        }
        $check->close();
    }

    header("Location: thankyou.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}
?>
