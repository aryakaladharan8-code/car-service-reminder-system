<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #abc1f1, #c9d8f8);
      font-family: 'Poppins', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .message-box {
      text-align: center;
      background: rgba(31, 31, 31, 0.85);
      padding: 50px;
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
      color: #00ffff;
      backdrop-filter: blur(10px);
    }

    h1 {
      font-size: 26px;
      margin-bottom: 20px;
      color: #00ffff;
    }

    p {
      font-size: 16px;
      color: #ccc;
      margin-bottom: 25px;
    }

    .btn {
      display: inline-block;
      padding: 12px 25px;
      background-color: #00ffff;
      color: #1f1f1f;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      transition: all 0.3s ease;
      box-shadow: 0 0 12px #b3e1f399;
    }

    .btn:hover {
      background-color: #00cccc;
    
      color: #000;
    }
  </style>
</head>
<body>
  <div class="message-box">
    <h1>✅ Thank you for booking your service!</h1>
    <p>Your service will be completed within <strong>two days</strong>. We’ll notify you once it’s done.</p>
    <a class="btn" href="userdashboard.php">🔙 Go to Dashboard</a>
  </div>
</body>
</html>
