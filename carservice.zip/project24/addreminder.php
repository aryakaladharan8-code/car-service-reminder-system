<?php
session_start();
$conn = new mysqli("localhost", "root", "", "carservice");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['userid'])) {
    die("You must be logged in to add a reminder.");
}

$userid = $_SESSION['userid'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $carnumber = $_POST['carnumber'];
    $type = $_POST['type'];
    $usmessage = $_POST['message'];

    $serviceTypes = [
        "Oil Change" => "+3 months",
        "Brake Inspection" => "+6 months",
        "Battery Replacement" => "+2 years",
        "Coolant Flush" => "+2 years",
        "Tire Rotation" => "+6 months",
        "Air Filter Replacement" => "+12 months",
        "Suspension Check" => "+12 months"
    ];

    if (array_key_exists($type, $serviceTypes)) {
        $sql = "SELECT MAX(servicedate) as last_service FROM bookings WHERE carnumber = ? AND servicetype = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $carnumber, $type);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $last_service_date = $row['last_service'];
        $stmt->close();

        $interval = $serviceTypes[$type];
        $reminderdate = $last_service_date ? date('Y-m-d', strtotime($last_service_date . " $interval")) : date('Y-m-d', strtotime($interval));
        $usmessage = "Your car $carnumber is due for $type on $reminderdate. Please schedule the service.";
    } else {
        $reminderdate = $_POST['reminderdate'];
        $usmessage = "Your car $carnumber $type is expiring on $reminderdate. Please renew it in time.";
    }

    $stmt = $conn->prepare("INSERT INTO reminders (userid, carnumber, type, reminderdate, message, notified) VALUES (?, ?, ?, ?, ?, 0)");
    $stmt->bind_param("issss", $userid, $carnumber, $type, $reminderdate, $usmessage);

    $message = $stmt->execute() ? "✅ Reminder added successfully!" : "❌ Failed to add reminder: " . $stmt->error;
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Reminder</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #d3e5ff);
      padding: 40px 15px;
    }

    form {
      max-width: 400px;
      

      margin: auto;
      background: rgba(255, 255, 255, 0.95);
      padding: 30px 28px;
      border-radius: 12px;
      border: 2px solid #090c14ff;
      box-shadow: 0 12px 25px rgba(0, 0, 0, 0.1);
      backdrop-filter: blur(5px);
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #1c2a44;
      font-size: 24px;
    }

    label {
      font-weight: 600;
      display: block;
      margin-top: 10px;
      margin-bottom: 5px;
    }

    input, select, textarea {
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #ccc;
      border-radius: 6px;
      margin-bottom: 18px;
      transition: all 0.3s ease;
    }

    input:focus, select:focus, textarea:focus {
      outline: none;
      border-color: #2563eb;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
    }

    textarea {
      resize: vertical;
    }

    button {
      width: 100%;
      padding: 14px;
      background: linear-gradient(135deg, #2563eb, #3b82f6);
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s ease;
      font-size: 15px;
    }

    button:hover {
      background: linear-gradient(135deg, #1d4ed8, #2563eb);
    }

    .msg {
      text-align: center;
      font-weight: bold;
      color: green;
      margin-bottom: 15px;
    }

    .back {
      text-align: center;
      margin-top: 20px;
    }

    .back a {
      text-decoration: none;
      color: #2563eb;
      font-weight: bold;
    }

    @media (max-width: 500px) {
      form {
        padding: 20px;
      }

      h2 {
        font-size: 20px;
      }
    }
  </style>
</head>
<body>

<form method="post" action="">
  <h2 style="font-size:20px; margin-bottom:15px;">➕ Add New Reminder</h2>

  <?php if ($message): ?>
    <p class="msg" style="font-size:14px; margin-bottom:12px;"><?= $message ?></p>
  <?php endif; ?>

  <label for="carnumber" style="font-size:14px;">Car Number:</label>
  <input type="text" name="carnumber" id="carnumber" required style="padding:8px; font-size:14px;">

  <label for="type" style="font-size:14px;">Reminder Type:</label>
  <select name="type" id="type" required style="padding:8px; font-size:14px;">
    <option value="">-- Select Type --</option>
    <optgroup label="📄 Legal Reminders">
      <option value="PUC">PUC Expiry</option>
      <option value="Insurance">Insurance Expiry</option>
      <option value="RC">RC Expiry</option>
      <option value="License">Driving License Expiry</option>
    </optgroup>
  </select>

  <div id="date_section">
    <label for="reminderdate" style="font-size:14px;">Reminder Date:</label>
    <input type="date" name="reminderdate" id="reminderdate" style="padding:8px; font-size:14px;">
  </div>

  <label for="message_box" style="font-size:14px;">Message:</label>
  <textarea name="message" id="message_box" rows="3" readonly style="padding:8px; font-size:13px;"></textarea>

  <button type="submit" style="padding:10px; font-size:14px;">💾 Save Reminder</button>

  <div class="back" style="margin-top:15px;">
    <a href="reminders.php" style="font-size:14px;">⬅ View My Reminders</a>
  </div>
</form>
<script>
document.addEventListener("DOMContentLoaded", function () {
  const typeField = document.getElementById("type");
  const reminderDateField = document.getElementById("reminderdate");
  const messageBox = document.getElementById("message_box");
  const carNumberField = document.getElementById("carnumber");

  function updateMessage() {
    const carNumber = carNumberField.value.trim();
    const type = typeField.value;
    const reminderDate = reminderDateField.value;

    if (!carNumber || !type || !reminderDate) {
      messageBox.value = "";
      return;
    }

    // Format the date nicely
    const formattedDate = new Date(reminderDate).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });

    const reminderText = `Your car ${carNumber} ${type} is expiring on ${formattedDate}. Please renew it in time.`;
    messageBox.value = reminderText;
  }

  typeField.addEventListener("change", updateMessage);
  reminderDateField.addEventListener("input", updateMessage);
  carNumberField.addEventListener("input", updateMessage);
});
</script>

  </body>
  </html>