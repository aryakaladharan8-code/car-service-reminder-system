<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

$userid = $_SESSION['userid'];

// Database connection
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user's name
$result = $conn->query("SELECT name FROM user WHERE userid = $userid");
$username = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['name'] : 'User';

// Monthly service data
$monthlyCounts = array_fill(1, 12, 0);
$monthlyServiceTypes = array_fill(1, 12, []);

$query = "SELECT servicedate, servicetype FROM bookings WHERE userid = $userid";
$res = $conn->query($query);

while ($row = $res->fetch_assoc()) {
    $month = (int)date("n", strtotime($row['servicedate']));
    $monthlyCounts[$month]++;
    $monthlyServiceTypes[$month][] = $row['servicetype'];
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>User Service Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    * { box-sizing: border-box; font-family: 'Poppins', sans-serif; }

    body {
      margin: 0;
      background: linear-gradient(to bottom right, #e5ecf4, #edf1fc);
      color: #1a1a1a;
    }

    .container {
      max-width: 1000px;
      margin: 40px auto;
      padding: 20px;
      background: #ffffffa6;
      backdrop-filter: blur(12px);
      border-radius: 20px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }

    .header {
      font-size: 28px;
      font-weight: 600;
      margin-bottom: 10px;
      color: #05204aff;
    }

    .subheading {
      font-size: 18px;
      margin-bottom: 30px;
    }

    canvas {
      background: #ffffff;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
      transition: transform 1s ease-out, opacity 1s ease-out;
      transform: translateY(40px);
      opacity: 0;
    }

    /* Chart rise-up effect */
    .show-chart {
      transform: translateY(0);
      opacity: 1;
    }

    .service-type-list {
      margin-top: 30px;
    }

    .service-month {
      margin-bottom: 20px;
      background: #ffffff33;
      border-radius: 12px;
      padding: 15px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.06);
    }

    .service-month h4 {
      margin: 0 0 10px;
      color: #05204aff;
    }

    .service-month ul {
      margin: 0;
      padding-left: 20px;
    }

    .service-month li {
      margin-bottom: 6px;
      font-size: 15px;
    }

    .nav-link {
      margin-top: 20px;
      display: inline-block;
      background: #05204aff;
      color: white;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      transition: 0.3s;
    }

    .nav-link:hover {
      background: #021426;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">Hello, <?php echo htmlspecialchars($username); ?> 👋</div>
    <div class="subheading">Here is your monthly service breakdown:</div>

    <!-- Bar Chart -->
    <canvas id="serviceChart" height="100"></canvas>

    <!-- Monthly Service Details -->
    <div class="service-type-list">
      <?php
      $monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
      foreach ($monthlyServiceTypes as $month => $services) {
          if (count($services) > 0) {
              echo "<div class='service-month'>";
              echo "<h4>{$monthNames[$month - 1]} Services</h4>";
              echo "<ul>";
              foreach ($services as $s) {
                  echo "<li>" . htmlspecialchars($s) . "</li>";
              }
              echo "</ul></div>";
          }
      }
      ?>
    </div>

    <a href="userdashboard.php" class="nav-link">← Back to User Dashboard</a>
  </div>

  <!-- Chart Script -->
  <script>
  const ctx = document.getElementById('serviceChart').getContext('2d');
  const chartCanvas = document.getElementById('serviceChart');
  const dataValues = <?php echo json_encode(array_values($monthlyCounts)); ?>;

  // Animate the chart rising into view when page loads
  window.addEventListener('load', () => {
    setTimeout(() => {
      chartCanvas.classList.add('show-chart');
    }, 200); // slight delay for smooth entrance
  });

  const chart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
      datasets: [{
        label: 'Services Taken',
        data: dataValues,
        backgroundColor: '#05204aff99',
        borderColor: '#05204aff',
        borderWidth: 1,
        borderRadius: 6
      }]
    },
    options: {
      animation: {
        duration: 1200,
        easing: 'easeOutCubic', // smooth vertical growth
        delay: (context) => {
          const value = context.dataset.data[context.dataIndex];
          return value > 0 ? context.dataIndex * 100 : 0; // stagger only for non-empty bars
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { precision: 0 },
          grid: { color: '#d8dee9' }
        },
        x: {
          grid: { display: false }
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#05204aff',
          titleColor: '#ffffff',
          bodyColor: '#ffffff',
          callbacks: {
            label: context => `${context.parsed.y} service(s)`
          }
        }
      }
    }
  });
  </script>
</body>
</html>
