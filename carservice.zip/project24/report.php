<?php
session_start();
$conn = new mysqli("localhost", "root", "", "carservice");
date_default_timezone_set('Asia/Kolkata');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
$currentYear = (int)date('Y');

$sql = "SELECT b.servicedate, u.name, u.email, b.phonenumber, b.carnumber FROM bookings b JOIN user u ON b.userid = u.userid WHERE YEAR(b.servicedate) = ? ORDER BY b.servicedate ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $currentYear);
$stmt->execute();
$result = $stmt->get_result();

$customersByMonth = [];
while ($row = $result->fetch_assoc()) {
    $month = (int)date('n', strtotime($row['servicedate']));
    $customersByMonth[$month][] = $row;
}

$uniqueCustomersYear = [];
$monthlyCounts = [];
foreach ($months as $idx => $mname) {
    $m = $idx + 1;
    $monthlyCounts[$m] = 0;
    if (!empty($customersByMonth[$m])) {
        $unique = [];
        foreach ($customersByMonth[$m] as $cust) {
            $key = strtolower(trim($cust['email']));
            $unique[$key] = $cust;
            $uniqueCustomersYear[$key] = $cust;
        }
        $monthlyCounts[$m] = count($unique);
    }
}
$yearlyTotal = count($uniqueCustomersYear);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Monthly Customer Report</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(to right, #f0f4ff, #e0e7ff);
      color: #232946;
    }
    .container {
      max-width: 1200px;
      margin: 40px auto;
      background: #ffffff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    }
    h2 {
      text-align: center;
      font-size: 2.2em;
      color: #2563eb;
      margin-bottom: 40px;
      letter-spacing: 1px;
    }
    .summary {
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 40px;
    }
    .summary-text {
      flex: 1;
      min-width: 250px;
    }
    .summary-text h3 {
      font-size: 1.4em;
      color: #1d4ed8;
      margin-bottom: 10px;
    }
    .summary-text p {
      font-size: 1em;
      color: #444;
      line-height: 1.6;
    }
    .summary-text .yearly-total {
      margin-top: 16px;
      font-weight: 600;
      font-size: 1.1em;
      color: #1e3a8a;
    }
    .chart-container {
      flex: 2;
      min-width: 320px;
    }
    .month-card {
      margin-bottom: 36px;
      background: #f9fafb;
      padding: 24px 20px;
      border-radius: 12px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
    }
    .month-title {
      font-weight: 600;
      font-size: 1.2em;
      color: #2563eb;
      margin-bottom: 18px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 10px;
    }
    th, td {
      padding: 12px 10px;
      text-align: left;
    }
    th {
      background-color: #2563eb;
      color: white;
      font-weight: 600;
    }
    tr:nth-child(even) td {
      background-color: #f1f5f9;
    }
    tr:hover td {
      background-color: #e0e7ff;
    }
    .unique-count {
      font-size: 1em;
      color: #1d4ed8;
      font-weight: 500;
      margin-top: 10px;
    }
    .no-data {
      color: #999;
      font-style: italic;
    }
    .back {
      display: block;
      margin: 40px auto 0 auto;
      width: fit-content;
      text-decoration: none;
      color: #ffffff;
      background: linear-gradient(90deg, #2563eb, #3b82f6);
      padding: 12px 28px;
      border-radius: 8px;
      font-weight: 500;
      transition: all 0.2s ease;
      box-shadow: 0 4px 14px rgba(59, 130, 246, 0.15);
    }
    .back:hover {
      background: linear-gradient(90deg, #1d4ed8, #2563eb);
      box-shadow: 0 6px 20px rgba(59, 130, 246, 0.2);
    }
    @media (max-width: 768px) {
      .summary { flex-direction: column; }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>📊 Monthly Customer Report (<?= $currentYear ?>)</h2>

    <div class="summary">
      <div class="summary-text">
        <h3>📅 Customer Trends</h3>
        <p>This chart shows how many <strong>unique customers</strong> booked services each month in <strong><?= $currentYear ?></strong>.</p>
        <div class="yearly-total">Total unique customers this year: <span style="color:#2563eb;"><?= $yearlyTotal ?></span></div>
      </div>
      <div class="chart-container">
        <canvas id="customerChart" height="120"></canvas>
      </div>
    </div>

    <script>
      document.addEventListener('DOMContentLoaded', function () {
        const ctx = document.getElementById('customerChart').getContext('2d');
        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: <?= json_encode($months) ?>,
            datasets: [{
              label: 'Customers',
              data: <?= json_encode(array_values($monthlyCounts)) ?>,
              backgroundColor: '#3b82f6',
              borderRadius: 8,
              maxBarThickness: 36
            }]
          },
          options: {
            responsive: true,
            plugins: {
              legend: { display: false },
              tooltip: {
                backgroundColor: '#1e3a8a',
                titleColor: '#fff',
                bodyColor: '#fff',
                callbacks: {
                  label: ctx => ' ' + ctx.parsed.y + ' customers'
                }
              }
            },
            scales: {
              x: {
                grid: { display: false },
                ticks: { color: '#111', font: { weight: 'bold' } }
              },
              y: {
                beginAtZero: true,
                grid: { color: '#e0e7ff' },
                ticks: { stepSize: 1, color: '#111', font: { weight: 'bold' } }
              }
            }
          }
        });
      });
    </script>

    <?php foreach ($months as $idx => $mname): $m = $idx + 1; ?>
      <div class="month-card">
        <div class="month-title"><?= $mname ?></div>
        <?php if (!empty($customersByMonth[$m])): ?>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Car Number</th>
                <th>Booking Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($customersByMonth[$m] as $cust): ?>
                <tr>
                  <td><?= htmlspecialchars($cust['name']) ?></td>
                  <td><?= htmlspecialchars($cust['email']) ?></td>
                  <td><?= htmlspecialchars($cust['phonenumber']) ?></td>
                  <td><?= htmlspecialchars($cust['carnumber']) ?></td>
                  <td><?= date('d M Y', strtotime($cust['servicedate'])) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          <div class="unique-count">Unique customers this month: <?= $monthlyCounts[$m] ?></div>
        <?php else: ?>
          <div class="no-data">No bookings for this month.</div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>

    <a class="back" href="admindashboard.php">← Back to Dashboard</a>
  </div>
</body>
</html>
