<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "carservice";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Sanitize inputs
$customername = $conn->real_escape_string($_POST['customername'] ?? '');
$phonenumber = $conn->real_escape_string($_POST['phoneno'] ?? '');
$email = $conn->real_escape_string($_POST['email'] ?? '');
$carnumber = $conn->real_escape_string($_POST['carnumber'] ?? '');
$carmodel = $conn->real_escape_string($_POST['carmodel'] ?? '');
$userid = 1; // static for test

$sql = "INSERT INTO customer (userid, customername, phoneno, email, carnumber, carmodel)
        VALUES ('$userid', '$customername', '$phonenumber', '$email', '$carnumber', '$carmodel')";

if ($conn->query($sql) === TRUE) {
    echo "✅ Customer added successfully!";
} else {
    echo "❌ Error: " . $conn->error;
}

$conn->close();
?>

