<!DOCTYPE html>
<html>
<head>
  <title>Booking Confirmation</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #e3f2fd;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }

    .box {
      background: white;
      padding: 40px;
      border-radius: 10px;
      text-align: center;
      box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    }

    .box h1 {
      color: #2ecc71;
    }

    .box a {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      background-color: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }

    .box a:hover {
      background-color: #2980b9;
    }
  </style>
</head>
<body>
  <div class="box">
    <h1>✅ Booking Confirmed!</h1>
    <p>Thank you for booking your car service with us.</p>
    <a href="bookService.php">Book Another Service</a>
  </div>
</body>
</html>
