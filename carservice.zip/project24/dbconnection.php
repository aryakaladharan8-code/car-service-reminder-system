<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "carservice"; // change this to your actual DB name

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("❌ Connection failed: " . mysqli_connect_error());
}
?>

