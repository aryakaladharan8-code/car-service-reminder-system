<?php
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET['bookingid'])) {
  die("No booking ID provided");
}

$bookingid = intval($_GET['bookingid']);

// Fetch booking and user info using prepared statement
$stmt = $conn->prepare("SELECT b.*, u.name AS customername, u.email AS useremail FROM bookings b JOIN user u ON b.userid = u.userid WHERE b.bookingid = ? LIMIT 1");
if ($stmt) {
    $stmt->bind_param('i', $bookingid);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$res || $res->num_rows == 0) {
        // fallback: try customer table (older schema)
        $stmt2 = $conn->prepare("SELECT b.*, c.customername, c.email FROM bookings b JOIN customer c ON b.userid = c.userid WHERE b.bookingid = ? LIMIT 1");
        if ($stmt2) {
            $stmt2->bind_param('i', $bookingid);
            $stmt2->execute();
            $res2 = $stmt2->get_result();
            if (!$res2 || $res2->num_rows == 0) {
                die("No invoice found for this booking.");
            }
            $data = $res2->fetch_assoc();
        } else {
            die("No invoice found for this booking.");
        }
    } else {
        $data = $res->fetch_assoc();
        // normalize keys
        if (empty($data['customername']) && !empty($data['useremail'])) {
            $data['customername'] = $data['name'] ?? '';
            $data['email'] = $data['useremail'];
        }
    }
} else {
    die("Query preparation failed.");
}

// Try to fetch invoice record if exists (include amount and paid status)
$invStmt = $conn->prepare("SELECT invoice_no, issuedate, amount, paid FROM invoices WHERE bookingid = ? LIMIT 1");
if ($invStmt) {
  $invStmt->bind_param('i', $bookingid);
  $invStmt->execute();
  $invRes = $invStmt->get_result();
  if ($invRes && $invRes->num_rows > 0) {
    $invRow = $invRes->fetch_assoc();
    $data['invoice_no'] = $invRow['invoice_no'];
    $data['invoice_issuedate'] = $invRow['issuedate'];
    $data['invoice_amount'] = $invRow['amount'];
    $data['invoice_paid'] = $invRow['paid'];
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Invoice #<?php echo $bookingid; ?></title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, sans-serif;
      background-color: #f5f7ff;
      padding: 30px;
    }

    .invoice-container {
      max-width: 800px;
      margin: auto;
      background: #fff;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #1e3a8a;
      padding-bottom: 10px;
      margin-bottom: 20px;
    }

    h1 {
      color: #1e3a8a;
      margin: 0;
    }

    .info p {
      margin: 4px 0;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 10px;
      text-align: left;
    }

    th {
      background-color: #1e3a8a;
      color: white;
    }

    .total {
      text-align: right;
      font-weight: bold;
    }

    .footer {
      text-align: center;
      margin-top: 30px;
      color: #666;
    }

    .btn-print {
      display: inline-block;
      margin-top: 20px;
      background-color: #1e3a8a;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 8px;
      font-weight: bold;
      transition: 0.3s;
    }

    .btn-print:hover {
      background-color: #000;
    }
  </style>
</head>
<body>

  <div class="invoice-container">
    <div class="header">
      <div style="display:flex; gap:18px; align-items:center;">
        <div style="width:84px; height:84px; background:linear-gradient(135deg,#eef2ff,#e0f2fe); border-radius:12px; display:flex; align-items:center; justify-content:center; font-weight:800; color:#1e3a8a;">CC</div>
        <div>
          <h1 style="margin:0; font-size:1.6em; color:#0f172a;">Car Care</h1>
          <div style="color:#475569; font-size:0.95em;">Quality car maintenance & repair</div>
        </div>
      </div>
      <div style="text-align:right;">
        <p style="margin:0;"><strong>Invoice No:</strong> <?php echo htmlspecialchars($data['invoice_no'] ?? ('INV-' . str_pad($bookingid, 4, '0', STR_PAD_LEFT))); ?></p>
        <p style="margin:0;"><strong>Date:</strong> <?php echo htmlspecialchars(!empty($data['invoice_issuedate']) ? date('d M Y', strtotime($data['invoice_issuedate'])) : date("d M Y")); ?></p>
      </div>
    </div>

    <div class="info">
      <p><strong>Customer:</strong> <?php echo htmlspecialchars($data['customername'] ?? ''); ?></p>
      <?php if (!empty($data['phonenumber']) || !empty($data['phone'])): ?>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($data['phonenumber'] ?? $data['phone'] ?? ''); ?></p>
      <?php endif; ?>
      <p><strong>Car Number:</strong> <?php echo htmlspecialchars($data['carnumber'] ?? ''); ?></p>
      <p><strong>Service Type:</strong> <?php echo htmlspecialchars($data['servicetype'] ?? ''); ?></p>
      <p><strong>Service Date:</strong> <?php echo htmlspecialchars($data['servicedate'] ?? ''); ?></p>
    </div>
    <?php
    // Only show full invoice if service completed
    $status = strtolower($data['status'] ?? '');
    if ($status !== 'completed'):
    ?>
      <div style="padding:30px; text-align:center; background:#fff7ed; border-radius:10px; border:1px solid #ffedd5;">
        <h2 style="color:#92400e;">Invoice Pending</h2>
        <p style="color:#92400e;">This service is not marked as <strong>Completed</strong> yet. An invoice will be available once the service is completed.</p>
        <p style="margin-top:12px; color:#555;">Current status: <strong><?php echo htmlspecialchars($data['status'] ?? 'N/A'); ?></strong></p>
      </div>
    <?php else:
        // ensure invoice exists (create if missing)
        if (empty($data['invoice_no'])) {
            $invoiceNo = 'INV-' . date('Ym') . '-' . str_pad($bookingid, 4, '0', STR_PAD_LEFT);
            $amount = isset($data['totalprice']) && $data['totalprice'] > 0 ? floatval($data['totalprice']) : floatval($data['price']);
            $ins = $conn->prepare("INSERT INTO invoices (bookingid, userid, invoice_no, amount, issuedate) VALUES (?, ?, ?, ?, NOW())");
            if ($ins) {
                $userid = intval($data['userid'] ?? $data['userid'] ?? 0);
                $ins->bind_param('iisd', $bookingid, $userid, $invoiceNo, $amount);
                $ins->execute();
                $data['invoice_no'] = $invoiceNo;
                $data['invoice_issuedate'] = date('Y-m-d H:i:s');
            }
        }

        // Car care tips by service type
        $careTips = [
            'Oil Change' => "Change oil every 5,000-10,000 km. Use recommended grade, check levels monthly.",
            'Full Service' => "Regular full service keeps all systems optimal; follow manufacturer intervals.",
            'Brake Inspection' => "Inspect pads and rotors for wear; replace pads before metal contact.",
            'Battery Check' => "Keep terminals clean, check charge & replace battery every 3-5 years.",
            'Coolant Flush' => "Replace coolant every 2 years to prevent overheating and corrosion.",
            'Tire Rotation' => "Rotate tires every 8,000-10,000 km and check pressure monthly.",
            'Air Filter Replacement' => "Replace air filter annually or every 12,000 km to maintain efficiency.",
            'Suspension Check' => "Check shocks/struts for leaks and wear; improves ride and tyre life.",
            'AC Repair' => "Run AC periodically; have refrigerant and compressor checked if cooling reduces."
        ];
        $serviceType = $data['servicetype'] ?? '';
        $tip = $careTips[$serviceType] ?? "Keep up with scheduled maintenance; clean & check fluids regularly.";

    ?>

      <div style="display:flex; gap:24px; flex-wrap:wrap; margin-top:18px;">
        <div style="flex:1; min-width:260px; background:#fff; padding:18px; border-radius:10px; box-shadow:0 6px 18px rgba(15,23,42,0.04);">
          <h3 style="margin-top:0; color:#1e3a8a;">Service Summary</h3>
          <p style="margin:6px 0;"><strong>Service:</strong> <?php echo htmlspecialchars($serviceType); ?></p>
          <p style="margin:6px 0;"><strong>Service Date:</strong> <?php echo htmlspecialchars(date('d M Y', strtotime($data['servicedate']))); ?></p>
          <p style="margin:6px 0;"><strong>Amount:</strong> ₹<?php echo number_format(isset($data['totalprice']) && $data['totalprice']>0 ? $data['totalprice'] : $data['price'], 2); ?></p>
          <p style="margin:6px 0;"><strong>Invoice No:</strong> <?php echo htmlspecialchars($data['invoice_no']); ?></p>
        </div>

        <div style="flex:1; min-width:260px; background:#fff; padding:18px; border-radius:10px; box-shadow:0 6px 18px rgba(15,23,42,0.04);">
          <h3 style="margin-top:0; color:#134e8a;">Garage Details</h3>
          <p style="margin:8px 0; color:#123; line-height:1.5;"><strong>Car Care</strong><br>
            123 Service Lane, Auto City<br>
            Phone: +91 98765 43210
          </p>
          <hr style="border:none; height:1px; background:#eef2ff; margin:12px 0;">
          <p style="font-size:0.95em; color:#334155;">GSTIN: 12ABCDE3456F7Z8 (if applicable)</p>
        </div>
      </div>

      <div style="margin-top:22px; padding:18px; background:#fff; border-radius:10px; box-shadow:0 6px 18px rgba(15,23,42,0.04);">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
          <div style="color:#374151; font-weight:600;">Grand Total</div>
          <?php
            // Prefer invoice amount if present, otherwise booking totalprice or price
            $grand = null;
            if (!empty($data['invoice_amount'])) {
                $grand = $data['invoice_amount'];
            } elseif (!empty($data['totalprice'])) {
                $grand = $data['totalprice'];
            } else {
                $grand = $data['price'] ?? 0;
            }
          ?>
          <div style="font-size:1.25em; font-weight:800; color:#6b5b95;">₹<?php echo number_format(floatval($grand), 2); ?></div>
        </div>
      </div>

      <div class="footer" style="margin-top:18px;">
        <p>Thank you for choosing our service! Drive safe.</p>
        <p style="font-size:0.85em; color:#7b8794;">This is a computer-generated invoice. For queries contact support.</p>
        <a href="#" class="btn-print" onclick="window.print(); return false;">🖨️ Print / Save as PDF</a>
      </div>

      <style>
        /* show a visible print button on screen and style it */
        .btn-print {
          display: inline-block;
          margin-top: 20px;
          background: linear-gradient(90deg,#0ea5a4,#047481);
          color: #fff;
          padding: 10px 18px;
          border-radius: 8px;
          text-decoration: none;
          font-weight: 700;
          box-shadow: 0 6px 18px rgba(4,116,129,0.14);
        }
        .btn-print:hover { transform: translateY(-2px); }
        @media print {
          .btn-print { display: none; }
        }
      </style>

    <?php endif; ?>
  </div>

</body>
</html>
