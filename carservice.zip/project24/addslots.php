<?php
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$slotdate = $_POST['slotdate'];
$pickupoption = $_POST['pickupoption'];
$slottimes = $_POST['slottime'] ?? []; // May not exist for no-pickup
$maxbookings = $_POST['maxbookings'] ?? 3;

// If pickup is required but no slots selected
if ($pickupoption === "pickup" && empty($slottimes)) {
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Slot Error</title>
        <style>
            body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                background-color: #82d1e7ff; /* Full page background */
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .message-box {
                width: 500px;
                padding: 40px;
                background-color: #ffdddd; /* Box background for error */
                color: #d8000c;
                font-weight: bold;
                text-align: center;
                border-radius: 25px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
                font-size: 18px;
                animation: fadeIn 1s ease-in-out;
            }
            @keyframes fadeIn {
                0% { opacity: 0; transform: translateY(-30px); }
                100% { opacity: 1; transform: translateY(0); }
            }
        </style>
    </head>
    <body>
        <div class="message-box">
            ⚠️ Please select at least one time slot for Pickup.
        </div>
    </body>
    </html>
    ';
    exit;
}

// Logic for Pickup → insert selected slots
if ($pickupoption === "pickup") {
    foreach ($slottimes as $slottime) {
        $check = $conn->prepare("SELECT * FROM availableslots WHERE slotdate = ? AND slottime = ? AND pickupoption = ?");
        $check->bind_param("sss", $slotdate, $slottime, $pickupoption);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows === 0) {
            $stmt = $conn->prepare("INSERT INTO availableslots (slotdate, slottime, maxbookings, currentbookings, pickupoption) VALUES (?, ?, ?, 0, ?)");
            $stmt->bind_param("ssis", $slotdate, $slottime, $maxbookings, $pickupoption);
            $stmt->execute();
        }
    }
}
// Logic for No Pickup → insert only one row with empty slottime
else {
    $check = $conn->prepare("SELECT * FROM availableslots WHERE slotdate = ? AND slottime = '' AND pickupoption = ?");
    $check->bind_param("ss", $slotdate, $pickupoption);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows === 0) {
        $stmt = $conn->prepare("INSERT INTO availableslots (slotdate, slottime, maxbookings, currentbookings, pickupoption) VALUES (?, '', ?, 0, ?)");
        $stmt->bind_param("sis", $slotdate, $maxbookings, $pickupoption);
        $stmt->execute();
    }
}

// ✅ Success message with full page background
echo '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Slot Added</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #dff2f7ff; /* Full page background */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .message-box {
            width: 500px;
            padding: 40px;
            background-color: #bbe2f5ff; /* Box background */
            color: #00529b;
            font-weight: bold;
            text-align: center;
            border-radius: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            font-size: 20px;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(-30px); }
            100% { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="message-box">
        ✅ Slot(s) added successfully!
    </div>
</body>
</html>
';

$conn->close();
?>
