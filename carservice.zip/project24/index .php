<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Car Service Index</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body, html {
      height: 100%;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: white; /* Background changed to white */
      overflow: hidden;
    }

    .container {
      position: relative;
      width: 100%;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .info-box {
      position: absolute;
      top: 30px;
      left: 50%;
      transform: translateX(-50%);
      padding: 20px 40px;
      text-align: center;
      z-index: 5;
      background-color: transparent;
      box-shadow: none;
      backdrop-filter: none;
      border-radius: 0;
      animation: slideFromTop 1s ease-out forwards;
      opacity: 0;
    }

    .info-box h1 {
      font-size: 2.8rem;
      font-weight: bold;
      margin-bottom: 1rem;
      color: black;
    }

    .info-box p {
      font-size: 1.2rem;
      margin-bottom: 2rem;
      color: black;
    }

    .button-container {
      display: flex;
      justify-content: center;
      gap: 20px;
    }

    .action-btn {
      display: inline-block;
      text-decoration: none;
      padding: 12px 30px;
      background-color: white;
      color: #000;
      border: 2px solid black;
      border-radius: 30px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .action-btn:hover {
      background-color: rgba(0, 123, 255, 0.3);
      transform: scale(1.05);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
    }

    .center-image {
      position: absolute;
      width: 500px;
      bottom: 50px;
      z-index: 1;
    }

    .car-image {
      position: absolute;
      width: 300px; /* Increased car size */
      bottom: 10px;
      left: -300px;
      animation: carStopShort 3s ease-out forwards;
      z-index: 3;
    }

    @keyframes carStopShort {
      0% {
        left: -300px;
      }
      100% {
        left: 15%;
      }
    }

    @keyframes slideFromTop {
      0% {
        transform: translate(-50%, -100%);
        opacity: 0;
      }
      100% {
        transform: translate(-50%, 0);
        opacity: 1;
      }
    }

  </style>
</head>
<body>

  <div class="container">
    <div class="info-box">
      <h1>Welcome to Car Care</h1>
      <p>A serviced car is a safer car. Don’t delay, book today.</p>
      <div class="button-container">
        <a href="login.php" class="action-btn">🔐Login</a>
        <a href="register.php" class="action-btn">📝Sign Up</a>
      </div>
    </div>

    <img src="indeximg2.jpg" alt="Car Tools" class="center-image" />
    <img src="sport-car.png" alt="Car" class="car-image" />
  </div>

</body>
</html>
