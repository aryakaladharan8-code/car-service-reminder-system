<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database connection
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$bookingid = isset($_POST['bookingid']) ? intval($_POST['bookingid']) : 0;
$status = isset($_POST['status']) ? trim($_POST['status']) : '';

if ($bookingid <= 0 || empty($status)) {
    die("Invalid booking ID or status.");
}

// --- Step 1: Check current color ---
$check = $conn->prepare("SELECT statuscolor FROM bookings WHERE bookingid = ?");
if (!$check) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}
$check->bind_param("i", $bookingid);
$check->execute();
$result = $check->get_result();
$row = $result->fetch_assoc();
$currentColor = $row['statuscolor'] ?? '';

// --- Step 2: Determine new color ---
$newColor = $currentColor;
if (strtolower($status) === "completed" && empty($currentColor)) {
    $newColor = "blue"; // only first time
}

// --- Step 3: Update status and color ---
$update = $conn->prepare("UPDATE bookings SET status = ?, statuscolor = ? WHERE bookingid = ?");
if (!$update) {
    die("Prepare failed (UPDATE): (" . $conn->errno . ") " . $conn->error);
}
$update->bind_param("ssi", $status, $newColor, $bookingid);
$update->execute();

// --- Step 4: Send email if completed ---
$message = '';
$boxClass = '';
if (strtolower($status) === "completed") {
    // get booking + user info (include userid for invoice creation)
    $stmt = $conn->prepare("SELECT u.email, u.name, b.totalprice, b.userid FROM bookings b
                            JOIN user u ON b.userid = u.userid
                            WHERE b.bookingid = ?");
    if (!$stmt) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }
    $stmt->bind_param("i", $bookingid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $email = $row['email'];
        $name = $row['name'];
        $totalprice = number_format($row['totalprice'], 2);
        $booking_userid = intval($row['userid']);

        // --- Create invoices table if it doesn't exist ---
        $createInvoicesSql = "CREATE TABLE IF NOT EXISTS invoices (
            invoiceid INT AUTO_INCREMENT PRIMARY KEY,
            bookingid INT UNIQUE,
            userid INT,
            invoice_no VARCHAR(50),
            amount DECIMAL(10,2),
            issuedate DATETIME,
            paid TINYINT DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        $conn->query($createInvoicesSql);

        // --- Insert invoice for this booking if not exists ---
        $checkInv = $conn->prepare("SELECT invoiceid, invoice_no FROM invoices WHERE bookingid = ? LIMIT 1");
        $checkInv->bind_param('i', $bookingid);
        $checkInv->execute();
        $invRes = $checkInv->get_result();
        if ($invRes && $invRes->num_rows > 0) {
            $invRow = $invRes->fetch_assoc();
            $invoiceNo = $invRow['invoice_no'];
        } else {
            $invoiceNo = 'INV-' . date('Ym') . '-' . str_pad($bookingid, 4, '0', STR_PAD_LEFT);
            $insertInv = $conn->prepare("INSERT INTO invoices (bookingid, userid, invoice_no, amount, issuedate) VALUES (?, ?, ?, ?, NOW())");
            $amt = floatval($row['totalprice']);
            $insertInv->bind_param('iisd', $bookingid, $booking_userid, $invoiceNo, $amt);
            $insertInv->execute();
            // ignore failure - invoice is best-effort
        }

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'aryakaladharan8@gmail.com';
            $mail->Password   = 'qzlehsgnkpmswcav';
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            $mail->setFrom('aryakaladharan8@gmail.com', 'Car Service Team');
            $mail->addAddress($email, $name);

            $mail->isHTML(true);
            $mail->Subject = "Your Car Service is Completed!";
            $invoiceLink = 'https://' . 
                (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost') .
                dirname($_SERVER['REQUEST_URI']) . "/invoice.php?bookingid=" . $bookingid;

            $mail->Body    = "
                <p>Hi <strong>$name</strong>,</p>
                <p>Your car service is completed successfully.</p>
                <p><strong>Total Amount : ₹$totalprice</strong></p>
                <p>Your invoice number: <strong>$invoiceNo</strong></p>
                <p>You can view or download your invoice here: <a href=\"$invoiceLink\">Open Invoice</a></p>
                <p>You can now collect your vehicle from our garage.</p>
                <p>Thank you!<br>Car Service Team</p>
            ";
            $mail->AltBody = "Hi $name,\n\nYour car service is completed successfully.\nTotal Amount Paid: ₹$totalprice\nYou can now collect your vehicle from our garage.\n\nThank you!\nCar Service Team";

            $mail->send();
            $message = "✅ Mail successfully sent to $email";
            $boxClass = "message-box";
        } catch (Exception $e) {
            $message = "❌ Mail could not be sent. Error: {$mail->ErrorInfo}";
            $boxClass = "error-box";
        }
    } else {
        $message = "❌ No matching customer found.";
        $boxClass = "error-box";
    }
} else {
    $message = "Status updated successfully (no email sent).";
    $boxClass = "message-box";
}

// --- Step 5: Show only email message ---
echo '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Email Status</title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #f7f7f7;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
.message-box {
    width: 500px;
    padding: 40px;
    background-color: #e6ffe6;
    color: #027a00;
    font-weight: bold;
    text-align: center;
    border-radius: 25px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    font-size: 20px;
    animation: fadeIn 1s ease-in-out;
}
.error-box {
    width: 500px;
    padding: 40px;
    background-color: #ffe6e6;
    color: #a10000;
    font-weight: bold;
    text-align: center;
    border-radius: 25px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    font-size: 20px;
    animation: fadeIn 1s ease-in-out;
}
@keyframes fadeIn {
    0% { opacity: 0; transform: translateY(-20px);}
    100% { opacity: 1; transform: translateY(0);}
}
</style>
</head>
<body>
    <div class="'.$boxClass.'">'.$message.'</div>
</body>
</html>';

$conn->close();
?>

<script>
setTimeout(() => {
    window.location.href = "admindashboard.php";
}, 3000);
</script>
