<?php
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Target date is 3 days from today
$target_date = date('Y-m-d', strtotime('+3 days'));

// Fetch reminders that match the date and are not yet notified
$sql = "SELECT * FROM reminders WHERE reminderdate = '$target_date' AND notified = 0";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $userid = $row['userid'];
    $carnumber = $row['carnumber'];
    $type = $row['type'];
    $message = $row['message'];
    $reminderdate = $row['reminderdate'];

    // Fetch user email
    $user_result = $conn->query("SELECT email,name  FROM user WHERE userid = $userid");
    $user = $user_result->fetch_assoc();
    $email = $user['email'];
    $name = $user['name'];

    // Set up PHPMailer
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Your SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = 'aryakaladharan8@gmail.com'; // Your email
        $mail->Password = 'qzlehsgnkpmswcav'; // Use App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('aryakaladharan8@gmail.com', 'Your Garage');
        $mail->addAddress($email, $name);

        $mail->isHTML(true);
        $mail->Subject = "Reminder: $type due on $reminderdate for $carnumber";
        $mail->Body = "
            <p>Hi $name,</p>
            <p>This is a friendly reminder that your <strong>$type</strong> for vehicle <strong>$carnumber</strong> is due on <strong>$reminderdate</strong>.</p>
            <p>$message</p>
            <p>Thank you,<br>Your Garage</p>
        ";

        $mail->send();

        // Update reminder as notified
        $reminder_id = $row['id'];
        $conn->query("UPDATE reminders SET notified = 1 WHERE id = $reminder_id");

    } catch (Exception $e) {
        echo "Mailer Error ({$email}): {$mail->ErrorInfo}";
    }
}

echo "Reminder check completed.";
?>
