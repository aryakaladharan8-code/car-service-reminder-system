<?php
session_start();
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch unique users who have bookings
// Fetch unique customers with combined car info
$sql = "
  SELECT 
    u.userid, 
    u.name, 
    u.email,
    GROUP_CONCAT(DISTINCT b.carnumber SEPARATOR ', ') AS carnumber,
    GROUP_CONCAT(DISTINCT b.phonenumber SEPARATOR ', ') AS phonenumber
  FROM bookings b
  INNER JOIN user u ON b.userid = u.userid
  GROUP BY u.userid, u.name, u.email
  ORDER BY u.userid ASC
";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Customer List - Admin Dashboard</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #c9d8f8ff;
      margin: 0;
      padding: 20px;
    }

    .container {
      max-width: 1200px;
      margin: auto;
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      padding: 30px;
    }

    h2 {
      text-align: center;
      color: #363e94ff;
      font-size: 26px;
      margin-bottom: 30px;
    }

    h2::before {
      content: "📋 ";
    }

    table {
      width: 100%;
      border-collapse: collapse;
      overflow: hidden;
    }

    th {
      background-color: #1e3a8a;
      color: white;
      padding: 14px;
      text-align: left;
    }

    td {
      padding: 12px 14px;
      border-bottom: 1px solid #ddd;
    }

    tr:nth-child(even) {
      background-color: #f0f4ff;
    }

    tr:hover {
      background-color: #e2ecff;
    }

    .back-link {
      margin-top: 20px;
      display: inline-block;
      background-color: #1e3a8a;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 5px;
    }

    .back-link:hover {
      background-color: #081f4a;
    }

    .no-data {
      text-align: center;
      color: #888;
      font-size: 16px;
      padding: 40px 0;
    }

    .export-btn {
      display: block;
      margin: 0 auto 20px auto;
      background-color: #1e3a8a;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 8px;
      font-size: 15px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .export-btn:hover {
      background-color: #000;
    }

    /* ✅ PRINT FIX: Ensures full content prints, no cut-off */
    @media print {
      html, body {
        background: #fff !important;
        color: #000 !important;
        margin: 0;
        padding: 0;
        height: auto !important;
        overflow: visible !important;
      }

      .container {
        box-shadow: none;
        border-radius: 0;
        padding: 10px;
        margin: 0;
        width: 100%;
        max-width: none;
      }

      .export-btn, .back-link {
        display: none !important; /* hide buttons */
      }

      table {
        width: 100%;
        border-collapse: collapse;
        page-break-inside: auto;
        font-size: 12px;
        table-layout: fixed;
        word-wrap: break-word;
      }

      th, td {
        padding: 6px;
        border: 1px solid #999;
        text-align: left;
      }

      thead {
        display: table-header-group;
      }

      tr {
        page-break-inside: avoid;
        page-break-after: auto;
      }

      @page {
        size: A4 portrait;
        margin: 10mm;
      }

      body {
        zoom: 0.9;
        transform: scale(0.9);
        transform-origin: top center;
      }
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Customer List</h2>

    <div style="text-align:center; margin-bottom:20px;">
      <button class="export-btn" onclick="window.print()">📄 Export as PDF</button>
    </div>

    <?php if ($result->num_rows > 0): ?>
      <table>
        <thead>
          <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Car Number</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['userid']); ?></td>
              <td><?php echo htmlspecialchars($row['name']); ?></td>
              <td><?php echo htmlspecialchars($row['email']); ?></td>
              <td><?php echo htmlspecialchars($row['phonenumber']); ?></td>
              <td><?php echo htmlspecialchars($row['carnumber']); ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p class="no-data">No customers found with bookings.</p>
    <?php endif; ?>

    <a href="admindashboard.php" class="back-link">← Back to Dashboard</a>
  </div>

</body>
</html>

<?php $conn->close(); ?>
