<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard - Car slot Reminder</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;600&display=swap" rel="stylesheet">
  <style>
  :root {
    --background: #e6f0fa;
    --sidebar: #1e3a5f;
    --card: #ffffff;
    --text: #1f2937;
    --accent: #2563eb;
    --danger: #ef4444;
    --shadow: rgba(0, 0, 0, 0.08);
  }

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Roboto', sans-serif;
    background-color: #c9d8f8ff;
    color: var(--text);
    display: flex;
    min-height: 100vh;
  }

  /* Sidebar */
  .sidebar {
    width: 240px;
    background-color: var(--sidebar);
    padding: 30px 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  .sidebar h2 {
    color: #ffffff;
    font-size: 22px;
    margin-bottom: 30px;
    text-align: center;
  }

  .nav-link {
    display: block;
    color: #ffffff;
    background-color: transparent;
    padding: 12px 15px;
    border-radius: 8px;
    margin-bottom: 15px;
    text-decoration: none;
    font-size: 16px;
    transition: background 0.3s ease;
  }

  .nav-link:hover {
    background-color: rgba(255, 255, 255, 0.15);
  }

  .logout {
    background-color: var(--danger);
    text-align: center;
    color: white;
  }

  .logout:hover {
    background-color: #dc2626;
  }

  /* Main Content */
  .main {
    flex-grow: 1;
    padding: 30px;
  }

  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 30px;
  }

  .header h1 {
    font-size: 28px;
    color: var(--accent);
  }

  .card {
    background-color: var(--card);
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px var(--shadow);
    margin-bottom: 25px;
  }

  .card h2 {
    color: var(--accent);
    margin-bottom: 10px;
  }

  .card p {
    font-size: 16px;
    line-height: 1.6;
    color: #374f51ff;
  }

  @media (max-width: 768px) {
    body {
      flex-direction: column;
    }

    .sidebar {
      width: 100%;
      flex-direction: row;
      justify-content: space-around;
      padding: 15px;
    }

    .sidebar h2 {
      display: none;
    }

    .nav-link {
      margin-bottom: 0;
      font-size: 14px;
      padding: 10px;
    }

    .main {
      padding: 20px;
    }
  }
</style>

</head>
<body>

<!-- Sidebar Navigation -->
<!-- Sidebar Navigation -->
<div class="sidebar">
  <div>
    <h2>🔧 Admin Panel</h2>
    <a href="viewcustomer.php" class="nav-link">👥 Customers</a>
    <a href="viewbooking.php" class="nav-link">📅 Bookings</a>
    <a href="pickuprequests.php" class="nav-link">🚚 Pickups</a>
    <a href="report.php" class="nav-link">📈 Reports</a>
    <a href="logout.php" class="nav-link logout">🚪 Logout</a>
  </div>
</div>


<!-- Main Dashboard -->
<div class="main">
  <div class="header">
    <h1>Welcome, Admin 🧰</h1>
  </div>

  <!-- Welcome Message -->
  <div class="card">
    <h2>👋 Hello again!</h2>
    <p>Let’s keep engines running and customers smiling. Monitor bookings, pickups and user details from this dashboard.</p>
  </div>
    <!-- Add New Slot Section -->
  
<!-- Add New Slot Section -->
<div class="card">
  <form action="addslots.php" method="post">
    <h2>🕒 Add New Slot</h2>

    <label>Date:</label>
<input type="text" name="slotdate" id="slotdate" readonly>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const slotdate = document.getElementById("slotdate");
    
    // Get tomorrow's date
    const today = new Date();
    today.setDate(today.getDate() + 1); // adds 1 day
    const tomorrow = today.toISOString().split('T')[0];
    
    // Set input value to tomorrow
    slotdate.value = tomorrow;

    // Prevent past dates selection
    slotdate.setAttribute('min', tomorrow);
});
</script>


    <label>Pickup Option:</label>
    <select name="pickupoption" id="pickupoption" required>
      <option value="pickup">Pickup</option>
      <option value="nopickup">No Pickup</option>
    </select><br><br>

    <div id="timeslotsection">
      <label>Select Time Slots:</label><br>
      <input type="checkbox" name="slottime[]" value="10 to 11 AM"> 10 to 11 AM<br>
      <input type="checkbox" name="slottime[]" value="11 to 12 PM"> 11 to 12 PM<br>
      <input type="checkbox" name="slottime[]" value="12 to 1 PM"> 12 to 1 PM<br>
      <input type="checkbox" name="slottime[]" value="1 to 2 PM"> 1 to 2 PM<br>
      <input type="checkbox" name="slottime[]" value="2 to 3 PM"> 2 to 3 PM<br>
      <input type="checkbox" name="slottime[]" value="3 to 4 PM"> 3 to 4 PM<br>
      <input type="checkbox" name="slottime[]" value="4 to 5 PM"> 4 to 5 PM<br>
      <input type="checkbox" name="slottime[]" value="5 to 6 PM"> 5 to 6 PM<br>
    </div>

    <br>
    <label for="maxbookings">Max Bookings Per Slot:</label>
    <input type="number" name="maxbookings" value="3" required><br><br>

    <button type="submit">Add Slot</button>
  </form>
</div>

<!-- Add this script before </body> -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const pickupOption = document.getElementById("pickupoption");
    const timeslotSection = document.getElementById("timeslotsection");

    function toggleTimeSlots() {
      if (pickupOption.value === "pickup") {
        timeslotSection.style.display = "block";
      } else {
        timeslotSection.style.display = "none";
      }
    }

    toggleTimeSlots();
    pickupOption.addEventListener("change", toggleTimeSlots);
  });
</script>



</body>
</html>
