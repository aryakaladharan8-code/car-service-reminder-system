<?php
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['customerid'])) {
    $customerid = (int) $_POST['customerid'];
    $sql = "DELETE FROM customer WHERE customerid = $customerid";

    if ($conn->query($sql) === TRUE) {
        header("Location: viewcustomer.php"); // Redirect back after deletion
        exit;
    } else {
        echo "❌ Error deleting customer: " . $conn->error;
    }
} else {
    echo "❌ Invalid request.";
}

$conn->close();
