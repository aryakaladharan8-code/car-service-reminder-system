<?php
session_start();
$conn = new mysqli("localhost", "root", "", "carservice");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

$userid = $_SESSION['userid'];
$result = $conn->query("SELECT * FROM reminders WHERE userid = $userid ORDER BY reminderdate ASC");
$today = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>🔔 Your Vehicle Reminders</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
:root {
    --accent: #1c2a44;
    --bg: #c4d1f0ff;
    --card: #f9f9ff;
    --upcoming: orange;
    --overdue: red;
    --completed: green;
}

body {
    font-family: 'Poppins', sans-serif;
    background-color: var(--bg);
    color: #333;
    padding: 40px 20px;
}

h2 {
    text-align: center;
    margin-bottom: 30px;
    color: var(--accent);
}

.dashboard-container {
    max-width: 900px;
    margin: auto;
    border: 2px solid black;
    background: var(--card);
    border-radius: 12px;
    padding: 30px 20px;
    box-shadow: 0 4px 18px rgba(0,0,0,0.08);
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 30px;
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: var(--accent);
    color: white;
}

tr:nth-child(even) {
    background-color: #f0f4ff;
}

tr:hover {
    background-color: #e4ecff;
}

.status-upcoming {
    color: var(--upcoming);
    font-weight: bold;
}

.status-overdue {
    color: var(--overdue);
    font-weight: bold;
}

.status-completed {
    color: var(--completed);
    font-weight: bold;
}

.no-data {
    text-align: center;
    padding: 20px;
    color: #999;
}

.back-link-container {
    text-align: center;
    margin-top: 20px;
}

.back-link {
    display: inline-block;
    text-decoration: none;
    background: var(--accent);
    color: #fff;
    padding: 10px 18px;
    border-radius: 6px;
    font-weight: bold;
    transition: all 0.3s ease;
}

.back-link:hover {
    background: #000;
    color: #fff;
}
</style>
</head>
<body>

<div class="dashboard-container">
    <h2>🔔 Your Maintenance Reminders</h2>

    <?php if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <th>Reminder Type</th>
            <th>Car Number</th>
            <th>Reminder Date</th>
            <th>Message</th>
            <th>Status</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()):
            $status_class = '';
            $status_text = '';
            if ($row['reminderdate'] < $today) {
                $status_class = 'status-overdue';
                $status_text = 'Overdue';
            } elseif ($row['reminderdate'] == $today) {
                $status_class = 'status-upcoming';
                $status_text = 'Due Today';
            } else {
                $status_class = 'status-upcoming';
                $status_text = 'Upcoming';
            }
        ?>
        <tr>
            <td><?= htmlspecialchars($row['type']) ?></td>
            <td><?= htmlspecialchars($row['carnumber']) ?></td>
            <td><?= htmlspecialchars($row['reminderdate']) ?></td>
            <td><?= htmlspecialchars($row['message']) ?></td>
            <td class="<?= $status_class ?>"><?= $status_text ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <?php else: ?>
        <div class="no-data">No reminders found. Add a new reminder to stay updated!</div>
    <?php endif; ?>

    <div class="back-link-container">
        <a class="back-link" href="userdashboard.php">🔙 Back to Dashboard</a>
    </div>
</div>

</body>
</html>
