<?php
session_start();
$conn = new mysqli("localhost", "root", "", "carservice");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

$userid = $_SESSION['userid'];
// include status (and totalprice) so we can decide whether to show invoice
$sql = "SELECT bookingid, servicetype, servicedate, price, totalprice, status 
  FROM bookings 
  WHERE userid = ? 
  ORDER BY servicedate DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userid);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Service History</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --accent: #1c2a44; /* Sidebar background color */
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: #c4d1f0ff;
      color: #333;
      padding: 40px 20px;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: var(--accent);
    }

    .dashboard-container {
      max-width: 900px;
      margin: auto;
      border: 2px solid black; 
      background: #f9f9ff;
      border-radius: 12px;
      padding: 30px 20px;
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
      background-color: #fff;
      border-radius: 10px;
      overflow: hidden;
    }

    th, td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: var(--accent);
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f0f4ff;
    }

    tr:hover {
      background-color: #e4ecff;
    }

    .no-data {
      text-align: center;
      padding: 20px;
      color: #999;
    }

    .back-link {
      display: inline-block;
      text-decoration: none;
      background: var(--accent);
      color: #fff;
      padding: 10px 18px;
      border-radius: 6px;
      font-weight: bold;
      transition: all 0.3s ease;
      text-align: center;
    }

    .back-link:hover {
      background: #000;
      color: #fff;
    }

    .back-link-container {
      text-align: center;
      margin-top: 20px;
    }
    .invoice-btn {
  background-color: #0ea5a4; /* teal */
  color: #fff;
  padding: 8px 14px;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 700;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
  box-shadow: 0 6px 18px rgba(14,165,164,0.12);
  display: inline-block;
}
.invoice-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 26px rgba(14,165,164,0.16);
}
/* Modal for embedded invoice */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(12,18,35,0.6);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}
.modal-overlay.active { display: flex; }
.modal-content {
  width: 90%;
  max-width: 900px;
  height: 90%;
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 12px 40px rgba(0,0,0,0.3);
  display: flex;
  flex-direction: column;
}
.modal-header { display:flex; align-items:center; justify-content:space-between; padding:12px 18px; background:#f3f6ff; border-bottom:1px solid #eef2ff; }
.modal-title { font-weight:700; color:#1c2a44; }
.modal-close { background:#ef4444; color:#fff; border:none; padding:8px 12px; border-radius:8px; cursor:pointer; font-weight:700; }
.modal-iframe { flex:1; border:0; width:100%; }

  </style>
</head>
<body>
  <div class="dashboard-container">
    <h2>🧾 Your Service History</h2>

    <?php if ($result->num_rows > 0): 
        $totalSpent = 0; ?>
    <table>
  <tr>
    <th>Service Type</th>
    <th>Service Date</th>
    <th>Service Price (₹)</th>
    <th>Invoice</th>
  </tr>

  <?php while ($row = $result->fetch_assoc()) { 
        $totalSpent += floatval($row['price']);
        $status = strtolower($row['status'] ?? '');
  ?>
    <tr>
      <td><?php echo htmlspecialchars($row['servicetype']); ?></td>
      <td><?php echo htmlspecialchars(date('d M Y', strtotime($row['servicedate']))); ?></td>
      <td><?php echo number_format($row['price'], 2); ?></td>
      <td>
        <?php if ($status === 'completed'): ?>
          <a href="#" class="invoice-btn invoice-open" data-bookingid="<?php echo intval($row['bookingid']); ?>">🧾 View / Print</a>
        <?php else: ?>
          <span style="display:inline-block; padding:6px 10px; border-radius:8px; background:#ffedd5; color:#92400e; font-weight:600;">Pending</span>
        <?php endif; ?>
      </td>
    </tr>
  <?php } ?>
</table>

    <div style="display:flex; justify-content:flex-end; gap:18px; align-items:center;">
      <div style="font-weight:600; color:#1c2a44;">Total Spent:</div>
      <div style="font-size:1.15em; font-weight:700; color:#6b5b95;">₹<?php echo number_format($totalSpent, 2); ?></div>
    </div>

    <?php else: ?>
      <div class="no-data">No bookings found. Start by booking your first service!</div>
    <?php endif; ?>

    <div class="back-link-container">
      <a class="back-link" href="userdashboard.php">🔙 Back to Dashboard</a>
    </div>
  </div>
  
  <!-- Invoice Modal (loads invoice.php in an iframe) -->
  <div id="invoiceModal" class="modal-overlay" role="dialog" aria-hidden="true">
    <div class="modal-content" role="document">
      <div class="modal-header">
        <div style="display:flex; gap:12px; align-items:center;">
          <div class="modal-title">Invoice</div>
        </div>
        <div>
          <button id="invoicePrint" class="modal-close" style="background:#0ea5a4;">Print</button>
          <button id="invoiceClose" class="modal-close" style="background:#ef4444; margin-left:8px;">Close</button>
        </div>
      </div>
      <iframe id="invoiceFrame" class="modal-iframe" src="about:blank" title="Invoice viewer"></iframe>
    </div>
  </div>

  <script>
    (function(){
      const modal = document.getElementById('invoiceModal');
      const iframe = document.getElementById('invoiceFrame');
      const closeBtn = document.getElementById('invoiceClose');

      function openModal(bookingId){
        iframe.src = 'invoice.php?bookingid=' + encodeURIComponent(bookingId);
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
      }

      function closeModal(){
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        // clear iframe to release memory
        iframe.src = 'about:blank';
      }

      // open on click
      document.querySelectorAll('.invoice-open').forEach(function(el){
        el.addEventListener('click', function(e){
          e.preventDefault();
          const id = this.getAttribute('data-bookingid');
          if (id) openModal(id);
        });
      });

      // close handlers
      closeBtn.addEventListener('click', closeModal);
      // print handler - attempt to print iframe content
      const printBtn = document.getElementById('invoicePrint');
      printBtn.addEventListener('click', function(){
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } catch (e) {
          // fallback: open invoice in new tab for printing
          const src = iframe.src;
          if (src && src !== 'about:blank') window.open(src, '_blank');
        }
      });
      // click outside modal content closes
      modal.addEventListener('click', function(e){
        if (e.target === modal) closeModal();
      });

      // close on ESC
      document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeModal(); });
    })();
  </script>
</body>
</html>
