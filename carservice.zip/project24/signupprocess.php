<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
$conn = new mysqli("localhost", "root", "", "carservice");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect and sanitize input
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$role = 'User'; // default role

// Basic validation
if (empty($name) || empty($email) || empty($password)) {
    die("All fields are required.");
}

// ✅ Corrected column name: userid
$check = $conn->prepare("SELECT userid FROM user WHERE email = ?");
if (!$check) {
    die("Prepare failed: " . $conn->error);
}
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    die("Email already registered. <a href='signup.php'>Try again</a>");
}
$check->close();

// Hash the password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insert into database
$stmt = $conn->prepare("INSERT INTO user (name, email, password, role) VALUES (?, ?, ?, ?)");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("ssss", $name, $email, $hashedPassword, $role);

if ($stmt->execute()) {
    // ✅ Get the newly inserted userid
    $_SESSION['userid'] = $conn->insert_id;
    header("Location: userdashboard.php");
    exit();
} else {
    echo "Registration failed: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
