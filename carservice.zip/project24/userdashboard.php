<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}
$userid = $_SESSION['userid'];
$conn = new mysqli("localhost", "root", "", "carservice");

// Get username
$result = $conn->query("SELECT name FROM user WHERE userid = $userid");
$row = $result->fetch_assoc();
$username = $row['name'];

// Total services
$service_result = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE userid = $userid");
$total_services = $service_result->fetch_assoc()['total'];

// Total reminders
$reminder_result = $conn->query("SELECT COUNT(*) AS total FROM reminders WHERE userid = $userid");
$total_reminders = $reminder_result->fetch_assoc()['total'];

// Upcoming reminder
$upcoming_reminder_result = $conn->query("SELECT reminderdate FROM reminders WHERE userid = $userid AND reminderdate >= CURDATE() ORDER BY reminderdate ASC LIMIT 1");
$upcoming_reminder = false;
if ($upcoming_reminder_result && $upcoming_reminder_result->num_rows > 0) {
    $upcoming_reminder = $upcoming_reminder_result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --sidebar-bg: #05204aff;       /* Dark navy sidebar */
            --main-bg: #edeff4ff;          /* Slightly lighter main content area */
            --card-bg: #1c2a44;          /* Medium navy cards */
            --text-main: #f1f5f9;        /* Soft off-white text */
            --accent: #3b82f6;           /* Electric blue accent */
            --accent-light: rgba(177, 191, 214, 0.97); /* Soft blue glow */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background-color: #abc1f1ff;
            color: var(--text-main);
        }

        .sidebar {
            width: 220px;
            background: var(--card-bg);
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgba(255,255,255,0.05);
        }

        .sidebar h2 {
            color: var(--accent);
            font-size: 22px;
            margin-bottom: 40px;
        }

        .sidebar a {
            color: var(--text-main);
            text-decoration: none;
            padding: 12px;
            margin: 5px 0;
            border-radius: 6px;
            background: transparent;
            transition: all 0.3s ease;
        }

        .sidebar a:hover {
            background: var(--accent);
            color: var(--main-bg);
            font-weight: 500;
            
        }

        .main-content {
    flex: 1;
    padding: 30px;
    background-color: #c9d8f8ff; /* ← pastel purple, or any other color */
    overflow-y: auto;
}

        .welcome-bar {
    font-size: 26px;
    font-weight: 600;
    margin-bottom: 20px;
    color: var(--accent); /* Apply electric blue to the whole message */
}

.welcome-bar span {
    /* You can remove this or keep it the same */
    color: var(--accent);
}


        .cards {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .card {
            flex: 1;
            min-width: 220px;
            background-color: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px var(--accent-light);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 12px var(--accent-light);
        }

        .card h3 {
            font-size: 16px;
            color: var(--accent);
            margin-bottom: 10px;
        }

        .card p {
            font-size: 26px;
            font-weight: bold;
            color: var(--text-main);
        }

        .image-box {
            background-color: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 10px var(--accent-light);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .image-box:hover {
            transform: scale(1.01);
            box-shadow: 0 4px 14px var(--accent-light);
        }

        .image-box img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Car Service</h2>
       <a href="dashboard.php">Dashboard</a>

        <a href="bookservice.php">Book a Service</a>
        <a href="servicehistory.php">Service History</a>
        <a href="addreminder.php">Make Reminders</a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="main-content">
        <div class="welcome-bar">Welcome, <span><?php echo htmlspecialchars($username); ?></span></div>

        <div class="cards">
            <div class="card">
                <h3>Total Services Booked</h3>
                <p><?php echo $total_services; ?></p>
            </div>
            <div class="card">
                <h3>Total Reminders</h3>
                <p><?php echo $total_reminders; ?></p>
            </div>
            <div class="card">
                <h3>Upcoming Reminder</h3>
                <p>
                    <?php
                    if ($upcoming_reminder) {
                        echo date("d M Y", strtotime($upcoming_reminder['reminderdate']));
                    } else {
                        echo "No upcoming reminder";
                    }
                    ?>
                </p>
            </div>
        </div>

        <div class="image-box">
            <img src="172051.jpg" alt="Car Service Banner">
        </div>
    </div>
</body>
</html>
