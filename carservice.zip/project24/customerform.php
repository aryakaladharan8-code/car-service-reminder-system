<?php
$conn = new mysqli("localhost", "root", "", "carservice");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['customername'];
    $email = $_POST['email'];
    $phonenumber = $_POST['phonenumber'];
    $carnumber = $_POST['carnumber'];
    $carmodel = $_POST['carmodel'];

    $sql = "INSERT INTO customer (customername, email, phonenumber, carnumber, carmodel)
            VALUES ('$name', '$email', '$phonenumber', '$carnumber', '$carmodel')";

    if ($conn->query($sql) === TRUE) {
        $message = "<span class='success'>✅ Customer registered successfully!</span>";
    } else {
        $error = $conn->error;
        $message = "<span class='error'>❌ Error: $error</span>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f8ff;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            max-width: 550px;
            margin: 60px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        label {
            margin-top: 15px;
            display: block;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        input[type="submit"] {
            margin-top: 25px;
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Register Customer</h2>

    <form method="POST" action="">
        <label for="customername">Name:</label>
        <input type="text" name="customername" id="customername" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <label for="phonenumber">Phone Number:</label>
        <input type="text" name="phonenumber" id="phonenumber" required pattern="\d{10}" maxlength="10">

        <label for="carnumber">Car Number:</label>
        <input type="text" name="carnumber" id="carnumber" required>

        <label for="carmodel">Car Model:</label>
        <input type="text" name="carmodel" id="carmodel" required>

        <input type="submit" value="Register Customer">
    </form>

    <?php if (!empty($message)): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>
</div>

</body>
</html>
